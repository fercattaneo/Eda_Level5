/*
 * Creado por: Agustin Casas y Fernanda Cattaneo
 * 22.08 EDA Level 5
 * 10/05/2022
 */

#include <string>
using namespace std;
#ifndef TEXT_H
#define TEXT_H

void getGenoma(char *file, string &genoma);
void invertString(string& originalString);
void printStrings(string& gen1result, string& gen2result, string& middlestr);

#endif
